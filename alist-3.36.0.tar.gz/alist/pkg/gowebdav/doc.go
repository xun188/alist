// Package gowebdav is a WebDAV client library with a command line tool
// included.
package gowebdav
